exports.handler = async function (_event, _context) {
    return {data: "Hello World"};
};
